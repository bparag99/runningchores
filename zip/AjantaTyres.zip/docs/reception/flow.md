# Reception / Billing Flow

## Plain English Flow

### 1. Open Reception Module
The user opens the billing screen from the main app navigation.

### 2. Enter Customer Details
The user enters the customer name, phone number, and any required billing metadata.

### 3. Add Items to the Bill
The user selects tyres or stock items to sell.
- Item quantity is entered
- Price is pulled from the inventory or product listing
- GST details are applied

### 4. Validate Inventory Availability
The app checks if the selected quantity is available in stock.
- If enough stock exists, the bill continues
- If not enough stock exists, the app shows a warning and prevents the sale

### 5. Calculate Totals
The system calculates:
- item subtotal
- GST amount
- total bill amount

### 6. Save Bill
The user saves the transaction.
The app stores the bill in the Reception / Billing sheet.

### 7. Update Inventory
The app reduces the inventory quantity of sold items.
- The inventory count is decreased based on the sale quantity
- Items sold from the same batch are tracked through batch references

### 8. Generate Sales Summary
The dashboard and summary data are refreshed after the bill is saved.

### 9. Search and Review
The user can search saved bills using:
- phone number
- purchase date
- registration date

## Feature-by-Feature Summary
- Create customer bill
- Add sold items
- Validate stock before sale
- Apply GST and compute totals
- Save billing data
- Reduce inventory stock
- Refresh dashboard totals
- Search historical bills
