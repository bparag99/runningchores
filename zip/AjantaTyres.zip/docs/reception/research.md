# Reception / Billing Research

## 1. Objective
The reception module is the customer billing workflow. It records sales transactions, calculates GST, maps sold items to inventory, and stores bill information in a dedicated billing sheet.

## 2. User Need
The shop owner needs a fast way to record what was sold to a customer, calculate the total, and keep a proper bill record for future reference.

## 3. Core Billing Fields
The billing table should include fields such as:
- BillId / BillNo
- Customer Name
- Customer Phone Number
- Date
- GST Number
- Item Name
- Item Description
- Quantity
- Selling Price
- GST Percentage
- GST Amount
- Total Amount
- Inventory Item Reference
- BatchId
- Payment Status
- Notes / Remarks

## 4. Sales Flow
The reception process should work as follows:
1. The user opens a new billing screen.
2. The user enters customer details.
3. The user adds one or more tyres/items to the bill.
4. The app maps the sold items to inventory stock.
5. The app calculates the GST and total amount.
6. The app stores the bill record in the billing sheet.
7. The inventory stock count is reduced.

## 5. Mapping Behavior
The sale mapping should work in a one-way direction:
- the billing record references the inventory and batch information
- the inventory record is reduced in quantity when sold
- reverse cross-mapping from bill to inventory is not required for every bill in this version

This keeps the data model simple while preserving sales traceability.

## 6. GST and Indian Billing Pattern
The app should follow a typical Indian billing workflow with:
- GST Number field for the business or customer context if applicable
- GST Percentage field
- GST Amount calculation
- Final bill total
- Seller-side bill references and invoice structure

## 7. Business Rules
- A bill can contain multiple item rows
- Each sold item should map to a stock item or batch item record
- Quantity sold cannot exceed quantity available in inventory
- When stock reaches zero, item should be flagged as unavailable
- Sales should be saved in the reception sheet and update summary metrics

## 8. Search Requirements
The Reception screen should support a search area with radio options:
- Search by Phone Number
- Search by Purchase Date
- Search by Registration Date

This allows quick retrieval of customer or bill records.

## 9. UX Expectations
- A simple invoice-style layout
- Quick add item flow
- Automatic total and GST calculations
- Clear display of customer information and itemized bill data
- Save and print-friendly experience for mobile use

## 10. Design Considerations for Figma
The billing screen should include:
- customer details section
- item list section
- GST and amount calculation section
- save bill action
- optional receipt preview
- quick navigation to previous sales records
