# Dashboard Flow

## Plain English Flow

### 1. User Opens App
After login, the app opens the dashboard as the default landing screen.

### 2. Dashboard Loads Data
The app fetches the latest sheet data from Google Drive and calculates summary values.

### 3. Data is Processed
The app reads:
- inventory records
- sales/billing records
- stock movements

### 4. Summary Cards are Displayed
The dashboard shows key information such as:
- total items in stock
- purchased quantity
- sold quantity
- discarded quantity
- total sales value

### 5. Recent Activity is Listed
The app may show recent stock additions or recent customer bills to help the owner understand daily activity.

### 6. User Navigates
From the dashboard, the user can go to:
- Inventory
- Reception
- Settings
- Profile

### 7. Refresh Behavior
When the app syncs with Google Drive, the dashboard updates automatically with the latest values.

## Feature-by-Feature Summary
- Overview of business health
- KPI summary cards
- Quick access to stock and bill workflows
- Recent activity indicator
- Direct navigation to operational modules
