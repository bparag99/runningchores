# Dashboard Research

## 1. Objective
The dashboard acts as the home screen for the tyre shop owner. It should provide a quick business summary so the owner can understand current stock health, sales performance, and daily activity at a glance.

## 2. Primary Users
- Shop owner
- Admin user

## 3. Functional Requirements
The dashboard should show:
- total inventory items
- total quantity available
- purchases made
- items sold
- discarded stock
- sales summary
- recent transactions or recent bill activity
- quick access to inventory and billing features

## 4. KPI Suggestions
Recommended cards:
- Total Stock Quantity
- Total Purchase Value
- Total Sales Value
- Discarded Items
- Today’s Bills
- Inventory Low Stock Items

## 5. Business Rules
- Values should be read from inventory and reception sheet data
- Dashboard must be updated after each stock upload or bill creation
- If data is not synced, dashboard should reflect last fetched state from Google Drive
- Summary data should be calculated from both inventory and billing records

## 6. UX Requirements
- Show summary cards at the top
- Use simple numbers with short labels
- Keep charts minimal, if any
- Provide direct navigation links to inventory and reception screens

## 7. Design Considerations for Figma
The dashboard should feel like a high-level management screen:
- top header with business title and user profile
- summary cards in a grid
- recent activity list
- quick action buttons for Upload Batch, Upload Single, and New Bill
- clear visual hierarchy with minimal clutter
