# Tyre Shop CRM Mobile App - System Overview

## 1. Purpose
This mobile application is a single-user tyre shop CRM designed for a shop owner to manage daily operations from a mobile device. It helps in tracking stock, creating bills, viewing sales history, and maintaining key shop records without the need for a backend database.

## 2. Business Context
The business deals in tyres and related inventory management. The owner needs a simple and fast way to:
- log in securely
- see a quick business summary
- add and manage inventory
- upload stock from purchase bills or individual stock entries
- create customer bills/receptions
- search by phone number or date
- keep records in a spreadsheet-based data layer connected to Google Drive

## 3. App Scope
The app is currently built for a single shop owner and is intended to be installed for one user on Google Play Store. It includes:
- Login / logout
- Dashboard
- Inventory management
- Reception / billing
- Settings and profile

## 4. User Profile
Primary user:
- Shop owner / admin
- Maintains inventory records and generates invoices for customers

## 5. Data Architecture
Instead of a traditional database server, the app uses a direct frontend approach:
- Flutter app
- Google Drive as the cloud storage layer
- Excel/CSV file as the data repository
- One spreadsheet file containing multiple sheets:
  - Inventory sheet
  - Reception / Billing sheet
  - User / Authentication sheet
- A repository-style class handles all read/write operations to the spreadsheet

## 6. Core Modules
### Dashboard
Shows summary information about:
- total purchases
- total sold
- total discarded
- inventory status
- sales overview
- recent business activity

### Inventory
Tracks stock items with fields such as:
- Id
- Name
- Description
- Category
- Sub-Category
- Cost Price
- Selling Price
- Image
- BatchId
- Quantity
- Reg. No.
- Date
- SAP Warranty Number
- Warranty Type
- Serial Number
- GST
- BillNo
- Upload Type

Inventory items are managed through two workflows:
- Batch upload
- Single stock upload

### Reception / Billing
Handles customer sales entries and generates bills based on the tyre inventory. It includes:
- customer details
- item selection
- GST values
- quantity mapping to inventory
- computed bill amount
- sales record storage

### Basic / Account Features
Includes:
- login
- logout
- profile management
- settings
- app-level preferences

## 7. Functional Requirements Summary
- The app must allow login using email and password.
- The app must read and write records via Google Drive Excel file.
- It must support inventory upload through manual entry and scanned document extraction.
- It must support batch and single stock flows.
- It must allow search by phone number or purchase date/registration date.
- It must maintain sales records and link them to inventory stock.
- It must calculate GST and total amounts.
- It must show key summaries and counts on the dashboard.

## 8. Design Notes for Figma
This app should be designed as a clean mobile-first, single-user dashboard with clear navigation and form flows. The most important user journeys are:
1. Login
2. Dashboard overview
3. Upload inventory
4. Review scanned bill data
5. Save stock items
6. Create customer bill
7. Search inventory or billing records
8. View settings/profile

## 9. Current Assumptions
- One owner/admin user only for now
- No multi-role support in v1
- Auto-sync with Google Drive on app open
- Batch upload generates multiple item records
- OCR based bill extraction is available with review/edit before final save

## 10. Business Value
This system reduces manual paperwork and helps the tyre shop owner manage stock and sales more efficiently using a low-cost spreadsheet-based mobile CRM. It is practical for a single-user operation and is designed to be extended later if the business grows.
