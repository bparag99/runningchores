# Ajanta Tyres - Customer Facing Product Overview

## 1. Product Summary
Ajanta Tyres is a mobile-first CRM and business management application designed for a tyre shop owner to manage daily operations efficiently. The solution helps the owner track stock, maintain tire inventory, generate customer bills, and monitor business performance from a single mobile platform.

The application is designed for a single-user business flow and supports quick decision-making using a simple mobile interface. It is intended to be installed for a single shop owner and connected to Google Drive-based spreadsheet storage for data management.

---

## 2. Business Need
A tyre shop typically handles several operational challenges:
- tracking tyre inventory by category, batch, and stock quantity
- monitoring purchase and sales activity
- generating customer bills quickly and accurately
- reducing manual errors in stock management
- keeping records in an organized and searchable format

Ajanta Tyres solves these needs by combining stock management, billing, and summary reporting in one simple app.

---

## 3. Key Features Implemented

### 3.1 Login and Access Management
- Secure login using email and password
- Role-based access for a single owner/admin user
- Logout support
- Session-based protection for business screens

### 3.2 Dashboard
The dashboard gives the business owner a quick overview of the business health.

Includes:
- total stock quantity
- total purchase value
- total sales value
- discarded items
- sales summary
- recent activity and updated business status

This summary helps the owner make faster decisions without opening multiple systems.

### 3.3 Inventory Management
The inventory feature manages the complete stock list of tyres in the shop.

Inventory records include:
- Id
- Name
- Description
- Category
- Sub-Category
- Cost Price
- Selling Price
- Image
- BatchId
- Quantity
- Reg. No.
- Date
- SAP Warranty Number
- Warranty Type
- Serial Number
- GST
- BillNo
- Upload Type

Inventory supports two important upload flows:
1. Batch Upload
   - used for buying a group of tyres together
   - multiple product records can be linked to the same batch
2. Single Stock Upload
   - used for adding a one-off tyre item

### 3.4 Scan and Data Extraction
The app supports both manual and scanned entry for inventory records.

The system allows:
- camera capture of supplier bill or invoice
- file upload from storage
- automatic extraction of available data from the document
- review and edit of the extracted values before saving

This reduces manual effort and helps maintain data accuracy.

### 3.5 Billing and Reception Module
The billing module helps the business owner create customer bills quickly.

It includes:
- customer name and contact details
- item selection from stock
- item quantity
- selling price
- GST amount
- total bill calculation
- saved billing record
- inventory stock deduction after sale

This module is designed to follow a standard Indian billing pattern with GST support and clear invoice-style calculation.

### 3.6 Search and Filtering
Users can search records based on:
- Phone Number
- Purchase Date
- Registration Date

This improves record lookup and helps the owner find item or billing information faster.

### 3.7 Settings and Profile
The app includes standard account management features:
- profile view and editing
- settings screen
- app preferences and sync controls
- logout action

### 3.8 Google Drive + Excel Data Management
The app is built as a front-end mobile solution that connects to a Google Drive-based Excel file, instead of using a traditional backend database.

The spreadsheet stores:
- Inventory data
- Billing / reception data
- User login information

A repository layer handles the app-to-sheet communication and keeps the business data organized.

---

## 4. User Experience Goals
The application is designed to be:
- simple and easy to use on a mobile phone
- quick for daily shop operations
- lightweight for a single-user environment
- clear enough for shop owners without technical knowledge
- fast in creating stock records and customer bills

---

## 5. Scope of the Current Version
This version of the system is intentionally focused on a single-user setup and includes the core functions needed by a tyre shop owner.

Current scope includes:
- login/logout
- business dashboard
- inventory management
- batch and single upload
- scan-based data entry
- billing/reception
- search and report summary
- settings and profile

Future enhancements can include:
- multi-user roles
- sales analytics dashboards
- customer database
- payment tracking
- supplier management
- branch expansion support

---

## 6. Product Value for the Business
Ajanta Tyres helps the shop owner to:
- keep stock organized
- reduce manual billing errors
- understand current sales and inventory health
- improve customer service speed
- maintain records in a simple, structured format
- run the business with a mobile-friendly tool

This makes the app highly useful for a local tyre business that needs operational visibility without the complexity of a large ERP system.

---

## 7. Example of Core Business Workflow
A typical business workflow in the app is:
1. User logs in.
2. Dashboard loads summary of current stock and sales.
3. Owner adds new tyre stock via batch or single upload.
4. Optional scan of purchase bill extracts data and allows corrections.
5. Owner saves inventory data.
6. Customer purchases tyres.
7. Owner creates a new bill in the Reception screen.
8. GST and total amount are calculated automatically.
9. Stock quantity is reduced after sale.
10. Dashboard updates with the latest stats.

---

## 8. Costing Estimate

### Estimated Project Cost
- Design: 1 week | 5000 INR
- Mock UI Wireframe: 1 week | 5000 INR
- Development: 4 weeks | 10,000 - 15,000 INR

### Total Estimated Range
- Minimum: 20,000 INR
- Maximum: 25,000 INR

> Note: This is an indicative estimate for a basic single-user mobile product prototype and initial implementation scope.

---

## 9. Final Statement
Ajanta Tyres is a practical and efficient mobile CRM solution for a tyre shop that needs product management, billing, and business tracking in one easy-to-use tool. It offers the key features required to run day-to-day shop operations with minimal complexity and low infrastructure overhead.
