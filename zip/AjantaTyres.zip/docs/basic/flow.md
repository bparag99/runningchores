# Basic / Account Features Flow

## Plain English Flow

### 1. App Launch
When the app is opened, it checks whether a valid user session exists.

### 2. Login Check
- If the user is already logged in, the app opens the dashboard.
- If no session exists, the app opens the login screen.

### 3. User Login
The user enters email and password.
- If the credentials match the user sheet, the app logs in.
- If they do not match, the app shows an error and asks the user to retry.

### 4. Main App Access
After successful login, the user can access:
- Dashboard
- Inventory
- Reception
- Settings
- Profile

### 5. Logout
From settings or profile, the user selects logout.
- The app clears the active session.
- The user is redirected to the login screen.

### 6. Profile Editing
The user can open the profile page to view or update their personal and business details.

### 7. Settings
The user can open settings to review app preferences and system information.

### 8. Security and Session Behavior
The app should ensure that private screens are blocked when no valid session is active.

## Feature-by-Feature Summary
- Login: authenticate using email and password
- Logout: end session and return to login
- Profile: manage user information
- Settings: configure app-related preferences
