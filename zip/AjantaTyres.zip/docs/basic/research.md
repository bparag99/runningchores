# Basic / Account Features Research

## 1. Objective
The basic module covers the non-business app functions required for access and personalization. It is designed for a single-user setup where the shop owner logs in, uses the app, and manages their account.

## 2. Functional Requirements
### Login
- User signs in with email and password
- Credentials are stored in a user sheet or a protected spreadsheet record
- Login screen includes:
  - email field
  - password field
  - login button
  - forgot password option (optional for v1)

### Logout
- User can log out from the profile or settings section
- The app should terminate the session and redirect to login

### Profile
- Show basic user profile information
- Include name, email, phone number, business name, and profile image (optional)
- Allow editing user details

### Settings
- App preferences section
- Theme or display preferences
- Storage sync settings
- Notification preferences (if needed in future)
- App version information

## 3. Business Rules
- Only one primary shop owner/admin user is allowed in the current version
- Login is email-based
- Session is maintained as long as the user stays signed in
- App should handle invalid credentials gracefully
- If the user is not logged in, all business pages should redirect to login

## 4. User Flow
The user starts on the login screen. After successful authentication, the app loads the dashboard and allows navigation to other modules. If the user is logged out, the app returns to the login screen.

## 5. UX Expectations
- Simple, minimal, and quick access
- Clear validation messages for empty fields
- Avoid too many settings in the first version
- Keep account management simple for a single-user workflow

## 6. Design Considerations for Figma
- Login screen should be clean and fast
- Use minimal fields for quick entry
- Keep profile/settings as secondary navigation items
- Maintain consistent brand styling with the rest of the app
