# Inventory Flow

## Plain English Flow

### 1. Open Inventory Module
The user opens the Inventory screen from the main navigation.

### 2. Search or Browse Data
The user can:
- search by phone number
- search by purchase date
- search by registration date
- browse all current inventory items

### 3. Choose Upload Method
The user taps Add Inventory or Upload Stock.
The app shows two options:
- Upload Batch
- Upload Single

### 4. Select Source Type
After choosing batch or single entry, the app shows a popup with three choices:
- Use Camera
- Use File Storage
- Manual Upload

### 5. Scan or Manual Entry
#### If camera or file is chosen
- The app captures or uploads an image of a bill or invoice
- OCR extracts the available data
- The app fills the inventory form with extracted values
- The user reviews and edits the form before saving

#### If manual upload is chosen
- The user fills the inventory form directly
- The user enters all required product details and stock metadata

### 6. Save Record
The app validates required values and saves the item to the inventory sheet.

### 7. Batch Record Handling
For batch entries:
- one purchase batch may create multiple item rows
- all rows share the same BatchId
- the batch metadata is stored with the item rows

### 8. Sales Mapping
When a product is sold, the sales record references the item and reduces stock quantity.

### 9. Dashboard Updates
After saving, the dashboard is refreshed to show updated purchase, stock, and sales values.

## Feature-by-Feature Summary
- Browse inventory records
- Search inventory by phone/date filters
- Add single stock entries
- Add multi-item batch uploads
- Use camera or file scan to extract data
- Edit scanned data before saving
- Track stock, batch, and bill references
- Update summary values after each transaction
