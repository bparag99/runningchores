# Inventory Research

## 1. Objective
The inventory module manages the tyre stock available in the shop. It records product details, stock quantity, purchase metadata, and mapping information needed for future sales and billing.

## 2. Core Inventory Fields
The inventory table stores the following item fields:
- Id
- Name
- Description
- Category
- Sub-Category
- Cost Price
- Selling Price
- Image
- BatchId
- Quantity
- Reg. No.
- Date
- SAP Warranty Number
- Warranty Type
- Serial Number
- GST
- BillNo
- Upload Type
- Purchase/Stock source details

## 3. Inventory Types
The inventory object is built using two main upload flows:

### 3.1 Batch Upload
This flow is used when the shop purchases a batch of tyres or stock from a supplier.
- Upload Type = Batch
- One purchase batch can generate multiple inventory records under one batch identifier
- BatchId is used to group records from the same purchase
- This supports traceability from inventory to supplier purchase source

### 3.2 Single Stock Upload
This flow is used when a single tyre entry is entered manually or scanned independently.
- Upload Type = Stock
- Used for one-off stock items or irregular stock additions
- Each stock item gets its own record and can still carry the same standard inventory data fields

## 4. Inventory Operations
### Add Inventory
The owner can add inventory through the following methods:
- Manual form entry
- Camera-based bill scan
- File upload scan
- Upload batch flow
- Upload single item flow

### Scan Upload Flow
The app should provide a popup after selecting Upload Batch or Upload Single.
The popup provides options:
- Use Camera
- Use File Storage
- Manual Upload

The scan flow should:
- capture or upload an image of the supplier invoice or purchase bill
- extract available fields from the image using OCR or a document extraction mechanism
- auto-populate the form template
- allow editing before saving
- save the data into the inventory sheet

## 5. Business Rules
- Inventory is maintained in a single table
- Each item can be linked to a BatchId
- A stock item can be related to a BillNo when sold
- Inventory quantity must be reduced when a sale is made
- Total purchases, sold, and discarded values must be tracked
- Inventory records can be searched by:
  - phone number
  - purchase date
  - registration date

## 6. Relationship with Reception
Inventory and reception are linked indirectly through the sale flow.
- When a customer bill is created, relevant inventory items are mapped to sales data
- Sale reduces stock count from the inventory table
- The app stores the bill reference, but the inventory side does not need a complex reverse mapping for all bills

## 7. Search and Filtering
Inventory screen should have a top search area with radio options:
- Search by Phone Number
- Search by Purchase Date
- Search by Registration Date

This allows quick record lookup for stock or purchase tracking.

## 8. Data Integrity Requirements
- Avoid duplicate BatchId values across mismatched records
- Keep consistent field names across app and sheet
- Always validate mandatory item fields before save
- Preserve image references and file names for scanned receipts

## 9. UX Expectations
- Clean inventory list with image thumbnails
- Batch upload should be clearly separated from single upload
- Scan and manual upload should present distinct choices to reduce user confusion
- The editing screen should allow quick changes before final save

## 10. Design Considerations for Figma
The inventory module should highlight:
- inventory card list
- search bar and filter radio buttons
- add inventory button with upload options
- batch vs single entry selection
- form screen with editable metadata
- scan review screen before save
